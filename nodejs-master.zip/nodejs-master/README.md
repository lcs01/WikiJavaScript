       Git node js pour la presentation du mercredi 26

ouvrir server2.js pour voir les instruction et les exemple de code présent  
