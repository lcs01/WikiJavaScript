/*
jshint esversion: 6
*/
/*node support es6 
    Actually is used for the server part of your website 
    if u want to use node u have to know JavaScript
    its like a new language for server 
    why node js ?
    node js can help you to do asynchronous task  
    if js is used like the standar way 
    need information on database asking to it 
    wait for receiving information 
    send information and creating the page with information

    asynchrone way using thread pool 
    by this way if another client comming it will treat all at the same time 
    with the same script he can do more task ...
    node have an event queue sending request in event loop , and finally in thread pool 
    when thread pool got a response he send it to the client 
    node have intern library and exeternal library are v8, libeio (thread pool), libev(event loop)
    Openssl(crypto), c-ares(dns).
    you can see more information on the github of nodejs

    sync vs async :
    
    //sync

    var content = fs.readFileSync('MyFile.txt'); //creating content var and read Myfile.txt
    console.log('My files :', content); // display content (executing this line need to exec first the one )

    //async 
    fs.readFile('MyFile.txt', (err, content) => { //read this file and when you read it exec next line
        if (err) {
            throw err;
        }
        console.log('My file : ' , content);
    });
    */

    //if i have other code it will work unless the first one is executed

    //advantage of nodejs is one language for all JavaScript 
    //npm node package manager , big comunity a lot of package (be care of security ...)
    //show doc of nodejs and devdoc.io

    
    //Hello World and a lil web server

    console.log('Hello world !');

    //to use some feature you will ahve to include library

    const http = require('http');

    let server = http.createServer();

    server.on('request', (request, response) => {

        console.log('Requete reçus');
        
        //response.end();
    });

    server.listen(8060);
    