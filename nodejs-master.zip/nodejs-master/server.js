
/*
jshint esversion: 6
*/

let http = require('http'); // on importe http
let fs = require('fs'); // on importe fs pour lire un fichier ou autre 
let url = require('url'); // import de la methode url

let server = http.createServer();

server.on('request', (request, response) => { 

    response.writeHead(200,{//renvoie au serveur un message 200 (la requete a fonctionner)
        'content-type': 'text/html; charset=utf-8'
    });
   
    console.log(request.url);

   

    console.log(url.parse(request.url, true)); // affiche pour tester 

    let query = url.parse(request.url, true).query; 

    if (query.name === undefined){

        response.write('Bonjour anonyme');
    }else {

    response.write(`bonjour ${query.name}`); 
    }
    response.end();
   /*  
    fs.readFile('index.html', 'utf-8', (err, data) => {
       
        if (err) {

            response.writeHead(404);
            response.end('Ce fichier n\'existe pas ! ');

        }else {

            response.writeHead(200, {
                'content-type': 'text/html; charset=utf-8'
            });
    
            response.end(data);
        }
    
    });
    */
});

server.listen(8080);


/*

let http = require('http');

http.createServer((request, response) => { 
    

    response.writeHead(200, {
        'content-type': 'text/html; charset=utf-8'
    });

    console.log('il ya eu une requête ');

    response.end('Salut comment ça va ');

}).listen(8080); */ 